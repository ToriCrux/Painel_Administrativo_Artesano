package com.sistema.proposta_service.config.exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) { super(message); }
}
